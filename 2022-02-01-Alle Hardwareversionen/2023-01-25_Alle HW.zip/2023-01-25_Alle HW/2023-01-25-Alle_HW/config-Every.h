#ifdef EVERY

//      Die auf dieser Registerkarte aktivierten #defines sind nur für die Klassikversion mit nano EVery  gültig.


//   ==================== TonUINO - Klassik mit Nano EVERY == Boardeinstellungen ===========================================
//    Nutzung in der Version Klassik mit Einzelkomponenten, und mit Nano EVERY.
//  - Für die Nutzung des Nano EVERY müssen in der Boardverwaltung die Arduino megaAVRboards installiert und ausgewählt werden.
//  - als Board den Arduino Nano Every auswählen
//  - Registeremulaton None(ATMEGA 4809) auswählen.
//  - Für die Nutzung von HardwareSerial mit dem DF-Player die TX/RX Pins zum DF-Player umlegen auf D0 und D1
//    in den Defines das Hardwareserial durch entfernen der Kommentarzeichen aktivieren.
//  - Softwareserial ist aber auch noch nutzbar. Dazu die ursprüngliche Pinbelegung lassen und Hardwareserial nicht aktivieren.
//  ===========================================================================================================================

// ******************** Auswahl der Optionen und Zusatzfunktionen  für Klassik mit Arduino Every ******************************

// uncomment or comment the " #define .... "  to enable or disable the additional function

// ---------------------- Debug Modus ----------------------------------------------------------------------------------
#define Konsole               // Zum Einsparen von Programmspeicher wird die vollständige Ausgabe
                              // auf den Seriellen Monitor nur bei Freigabe ausgeführt.
                              // Bei aktiver LED-Animation, wird diese deaktiviert, um den Programmspeicher
                              // für die Konsolenausgabe frei zu machen.

// ---------------------- Abschaltung über Hardware - Pololu-Switch, MosFet, u.s.w. -- Klassik mit EVERY ----------------
#define HW_PowerOff            // Abschaltung über Hardware, wie Mosfet oder Pololu-Switch
//#define PololuSwitch           // Abschaltung über PololuSwitch 
// -----------------------------------------
// Hardwareabhängige defines nicht verändern  
  #ifdef HW_PowerOff           // Festlegen des Ausschalt-Signals, (HIGH oder LOW)
   #ifndef PololuSwitch        // ohne PololuSwitch
   #define LowActive           // LOW Pegel schaltet den TonUINO aus.
   #endif
  #endif                       
// ---------------------- USB Stick als Speichermedium --- Nur TonUINO Klassik -------------------------------------------
//#define UsbStick              // An Stelle der SD-Karte arbeitet der DF-Player mit einem USB-Stick
                               // Hardwareerweiterung erforderlich: (USB - A Buchse am DF-Player angeschlossen)

// ---------------------- Kopfhörer --- TonUINO Klassik mit Every---------------
//  #define Jackdetekt         // Jackdetekt mit Nutzung Kopfhörer-Buchse oder Platine mit Jackdetekt.
                               // Das ermöglicht zusätzlich die Lautstärken für Lautsprecher und Kopfhörer
                               // getrennt einzustellen. Die jeweiligen Lautstärkeeinstellungen bleiben 
                               // bis zum Ausschalten des TonUINO gespeichert.
                               // Im Adminmenü können die Lautstärke Voreinstellungen für LSP und KH getrennt
                               // programmiert werden. 


#ifdef Jackdetekt              // Wenn Jackdetekt oder JackdetektAiO aktiviert sind

// -------------------- Festlegen des Sensorpegels für den Kophöreranschluss --- Nur TonUINO Klassik ------------------------------
//#define KHSensLOW             // Der Sensorpegel für den Kopfhöreranschluss ist bei eingestecktem Kopfhörer LOW
                              // Wenn der Sensorpegel bei eingestecktem Kopfhörer HIGH ist, #define KHSensLOW deaktivieren

#define EarPhone              // Abschaltung des Lautsprechers über Software, wenn Kopfhörer angeschlossen sind
    #ifdef EarPhone           // Hardwareerweiterung erforderlich: (Kopfhöerbuchse mit Schaltkontakten, oder Kopfhöreranschlussplatine)
      #ifndef SpkOnOff        // wenn SpkOnOff nicht aktiviert ist, wird diese Funktion automatisch mit aktiviert
        #define SpkOnOff      // Hardwareerweiterung erforderlich: (TonUINO Klassik, - Abschaltung des Lautsprechers über MOS-FET's)
      #endif                  
    #endif                    
#endif



// ------------------- Überwachung der Batteriespannung ---------------------------------------------------------------------------
//#define BatteryCheck      // Kann beim EVERY nur im 3 Tasten-Modus verwendet werden, da AnalogPin A4 im 5 Tastenmodus belegt ist.
                            // Wenn ein anderer Analogpin frei zur Nutzung ist, kann dieser für BatteryCheck verwendet werden.
                            // Vor den BatteryCheckPin einen 100kOhm Widerstand in Reihe schalten (Klassik).

//                           ___________________________________________________________________________________
  // Festlegung der Spannungswerte für die Batterieüberwachung. Kann hier angepasst werden.

 #ifdef BatteryCheck               // Die Akkuspannung wird überwacht
                                   // Hardwareerweiterung erforderlich (Batteriespannung muss bei ausgeschaltetem Tonuino
                                   // vom Eingang des Arduino getrennt sein. (Nur TonUINO Klassik,MosFet oder Relais)
                                   // bei Unterschreiten des BatLow - Wertes wird eine Warnung ausgegeben
                                   // bei Erreichen des BatEmpty - Wertes wird der Tonuino ausgeschaltet.
                                   // Vor Abschalten erfolgt ein Ausfaden der Lautstärke über 20 Sekunden.
                                   
 // Wenn für den TonUINO Klassik mit Nano, oder Nano-Every der 5 Tastenmodus aktiviert wurde, wird dieser bei aktiviertem
 // BatteryCheck auf den 3 Tasten-Modus zurückgeschaltet.

   #ifdef FIVEBUTTONS
    #undef FIVEBUTTONS
   #endif
   
 // --------------------------------------- Akkutyp festlegen --------------------------------------------------------
                                   
 #define LiFePo                    // Lithium-Eisen-Phosphat-Akku ( LiFePO4) 
 
 //#define LiPo                     // Lithium-Ion oder Lithium-Polymer Akku (Li oder LiPo)

 #ifdef LiFePo
  const float BatLow = 2.95 ;      // Spannungswert für Warnung
  const float BatEmpty = 2.90 ;    // Spannungswert für automatische Abschaltung über Software ShutDown.
 #endif

 #ifdef LiPo
   const float BatLow = 3.2 ;      // Spannungswert für Warnung "Batterie schwach"
   const float BatEmpty = 3.0 ;    // Spannungswert für automatische Abschaltung über Software ShutDown.
 #endif

 // -------------------------------- TonUINO Klassik mit Nano Every -------------------------------------- 
                                   // Batteriespannung über 100kOhm/100kOhm Spannungsteiler an BattCheckPin anlegen
  const float correction = 2.0 ;   // Korrekturwert für Spannungsteiler (Anpassung der Anzeige an die tatsächliche Batteriespannung)
 
  
 #endif  // Ende #ifdef Batterycheck
// ------------------------------------------------------------------------------------------------------------------------------------
  #define Hardwareserial          // Nutzung von HardwareSerial (serial1) anstatt SoftSerial. Pins müssen umgelegt werden.
                                  // D0 RX, D1 TX  

// ------------ Max Matrixwert des Buttonboards ------------------------------------------------------------------------------
 #ifdef Buttonboard
 uint16_t mapMax = 790;
 #endif

 // ------------ Logischer Wert für Lautsprecher on oder off -(Wert nicht verändern) ---------------------------------------------------
 
 uint8_t On = 1;        // HIGH-Pegel
 uint8_t Off = 0;       // LOW-Pegel
 

// ***************************************************************************************************

//******************* Definitionen der Pins für TonUINO Klassik und EVERY ****************************

// ------------------ Analog-Pins -------------------------------
// --------------- 3 und 5 Button-Version -----------------------
#ifndef Buttonboard                // 3 Tasten-Version
 #define ButtonPause A0            // Taste 1 - Play / Pause
 #define ButtonUp A1               // Taste 2 - Vor / Lauter
 #define ButtonDown A2             // Taste 3 - Zurück / Leiser

 #ifdef FIVEBUTTONS                // 5 Tasten-Version
 #define ButtonFourPin A3          // Taste 4 - Lauter / Vor
 #define ButtonFivePin A4          // Taste 5 - Leiser / Zurück
 #endif
 #ifndef FIVEBUTTONS
 #ifdef BatteryCheck               // Batterieüberwachung
 #define BatteryCheckPin A4        // Kontrollpin für Batterieüberwachung (Umdeklarierbar, wenn ein anderer Analogpin bei Nichtnutzung frei wird.)
 #endif
 #endif                            
#endif

// --------------- Mit 12-Buttonboard -----------------------------
#ifdef Buttonboard                 // 12 Tasten-Version mit Buttonboard
 #define Buttonmatrix A2           // Tastenmatrix 9 Tasten
 #define ButtonPause A0            // Taste 1 - Play / Pause
 #define ButtonUp A3               // Taste 2 - Vor / Lauter
 #define ButtonDown A4             // Taste 3 - Zurück / Leiser
 
 #ifdef BatteryCheck               // Batterieüberwachung
 #define BatteryCheckPin A1        // Kontrollpin für Batterieüberwachung 
 #endif                            
#endif
// --------------------------------------------------------------
#ifdef EarPhone
#define EarPhonePin A5            // Kontrollpin Kopfhörer angeschlossen
#endif

#ifdef Wecker
#define WeckerPin A6              // Eingangspin zum Abspielen Wecker-shortcut
#endif

#define RandomPin A7              // Floating Pin zur Gewinnung einer Zufallszahl

// ----------------- Digital-Pins ---------------------------------
// die Pins D0 und D1 werden bei der Version mit Nano Every und Hardwareserial für Serial1 zum DF-Player verwendet

#define BusyPin 4                 // Auswertung des Busy Signals vom DF-Player
#define LedPin 5                  // Daten für Neopixel-LED-Ring

#ifdef SpkOnOff
#define SpkOnPin 6                // Schaltsignal Lautsprecher Ein/Aus
#endif

#ifdef HW_PowerOff
#define ShutDownPin 7             // Abschaltsignal für MosFet oder Polulo-Switch
#endif

#ifdef UsbStick
#define UsbPowerPin 8             // Schaltsignal für Power USB-Stick
#endif

#define RstPin 9                  // MFRC 522 -RST
#define CS_Pin 10                 // MFRC 522 -SDA (CS)


#endif
