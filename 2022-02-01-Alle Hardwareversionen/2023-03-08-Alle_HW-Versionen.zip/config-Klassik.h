#ifdef Klassik

//      Die auf dieser Registerkarte aktivierten #defines sind nur für die Klassik-Version gültig.


//   ======================= TonUINO - Klassik == Boardeinstellungen ================================================
//   - Für die Nutzung in der Version Klassik mit Einzelkomponenten, 
//     Nano 328P oder Nano 328P(Old Bootlader) je nach Version auswählen.
//  =================================================================================================================

// ******************** Auswahl der Optionen und Zusatzfunktionen für Tonuino Klassik *******************************

// uncomment or comment the " #define .... "  to enable or disable the additional function

// --------------------- Debug Modus --- Klassik mit Arduino NANO oder UNO -----------------------------------
//#define Konsole
// Zum Einsparen von Programmspeicher wird die vollständige Ausgabe auf den Seriellen Monitor nur bei Freigabe ausgeführt.
// ---------------------------------------------------------------
// Hardwareabhängige Zusatzdefinitionen (Hier nichts ändern)
 #ifdef Konsole               // Bei aktiver LED-Animation, wird diese deaktiviert, um den Programmspeicher
  #ifdef LED_SR               // für die Konsolenausgabe frei zu machen.
  #undef LED_SR
  #ifdef LED_SR_Switch
  #undef LED_SR_Switch
  #endif
  #endif
#endif
// ---------------------- Abschaltung über Hardware - Pololu-Switch, MosFet, u.s.w. -- Klassik -----------------------
#define HW_PowerOff            // Abschaltung über Hardware, wie Mosfet oder Pololu-Switch
//#define PololuSwitch          // Abschaltung über PololuSwitch 
// -----------------------------------------
// Hardwareabhängige defines nicht verändern  
  #ifdef HW_PowerOff           // Festlegen des Ausschalt-Signals, (HIGH oder LOW)
   #ifndef PololuSwitch        // ohne PololuSwitch
   #define LowActive           // LOW Pegel schaltet den TonUINO aus.
   #endif
  #endif                       
                          
// ---------------------- Abschaltung durch die Powerbank bei Unterschreiten der Mindestlast -- I < 27 mA -- nur Klassik ----
//#define LowCurrPwDown  

// Die Stromaufnahme des Tonuino wird auf < 27 mA reduziert.
// Die Abschaltung erfolgt durch die Powerbank. 
// Bei Unterschreitung der Mindestlast schaltet die Powerbank selbstständig automatisch aus.
// Die Powerbank muss das Abschalten bei Unterschreiten eines minimalen Laststromes unterstützen.
                               
// ---------------------- USB Stick als Speichermedium --- Nur TonUINO Klassik ----------------------------------------------
//#define UsbStick             
 // An Stelle der SD-Karte arbeitet der DF-Player mit einem USB-Stick Hardwareerweiterung erforderlich: (USB - A Buchse am DF-Player angeschlossen)


// ---------------------- Kopfhörer --- TonUINO Klassik ------------------------------------------------------------------

//#define Jackdetekt 

// Jackdetekt Klassik mit Nutzung Kopfhörer-Buchse oder Platine mit Jackdetekt.
// Das ermöglicht zusätzlich die Lautstärken für Lautsprecher und Kopfhörer getrennt einzustellen. 
// Die jeweiligen Lautstärkeeinstellungen bleiben bis zum Ausschalten des TonUINO gespeichert.
// Im Adminmenü können die Lautstärke Voreinstellungen für LSP und KH getrennt festgelegt werden. 

// -------------------- Festlegen des Sensorpegels für den Kophöreranschluss ---------------------------------------------
#ifdef Jackdetekt               // Wenn Jackdetekt aktiviert ist

//#define KHSensLOW 

// Der Sensorpegel für den Kopfhöreranschluss ist bei eingestecktem Kopfhörer LOW
// Wenn der Sensorpegel bei eingestecktem Kopfhörer HIGH ist, #define KHSensLOW deaktivieren

// Hardwareabhängige Zusatzdefinitionen(Hier nichts ändern)-------------------------
#define EarPhone              // Abschaltung des Lautsprechers über Software, wenn Kopfhörer angeschlossen sind
    #ifdef EarPhone           // Hardwareerweiterung erforderlich: (Kopfhöerbuchse mit Schaltkontakten, oder Kopfhöreranschlussplatine)
      #ifndef SpkOnOff        // wenn SpkOnOff nicht aktiviert ist, wird diese Funktion automatisch mit aktiviert
        #define SpkOnOff      // Hardwareerweiterung erforderlich: (TonUINO Klassik, - Abschaltung des Lautsprechers über MOS-FET's)
      #endif                  
    #endif                    
#endif

// ------------------- Überwachung der Batteriespannung -----------------------------------------------------------
//#define BatteryCheck 
// Kann beim Klassik nur im 3 Tasten-Modus verwendet werden, da AnalogPin A4 im 5 Tastenmodus belegt ist.
// Wenn ein anderer Analogpin frei zur Nutzung ist, kann dieser für BatteryCheck verwendet werden.
// Vor den BatteryCheckPin einen 100kOhm Widerstand in Reihe schalten (Klassik).

//___________________________________________________________________________________
  // Festlegung der Spannungswerte für die Batterieüberwachung. Kann hier angepasst werden.

 #ifdef BatteryCheck               // Wenn die Batteriespannungskontrolle aktiviert ist:
  // Hardwareerweiterung erforderlich
  // (Batteriespannung muss bei ausgeschaltetem Tonuino vom Eingang des Arduino getrennt sein. (Nur TonUINO Klassik,MosFet oder Relais)
  // Bei Unterschreiten des BatLow - Wertes wird eine Warnung ausgegeben
  // Bei Erreichen des BatEmpty - Wertes wird der Tonuino ausgeschaltet.
  // Vor Abschalten erfolgt ein Ausfaden der Lautstärke über 20 Sekunden.

 // Wenn für den TonUINO Klassik mit Nano, oder Nano-Every der 5 Tastenmodus aktiviert wurde, wird dieser bei aktiviertem
 // BatteryCheck auf den 3 Tasten-Modus zurückgeschaltet.

   #ifdef FIVEBUTTONS
    #undef FIVEBUTTONS
   #endif
  
 // --------------------------------------- Akkutyp festlegen --------------------------------------------------------
                                                                     
 #define LiFePo                    // Lithium-Eisen-Phosphat-Akku ( LiFePO4)
 
 //#define LiPo                     // Lithium-Ion oder Lithium-Polymer Akku (Li oder LiPo)

 #ifdef LiFePo
  const float BatLow = 2.95 ;      // Spannungswert für Warnung
  const float BatEmpty = 2.90 ;    // Spannungswert für automatische Abschaltung über Software ShutDown.
 #endif

 #ifdef LiPo
   const float BatLow = 3.2 ;      // Spannungswert für Warnung "Batterie schwach"
   const float BatEmpty = 3.0 ;    // Spannungswert für automatische Abschaltung über Software ShutDown.
 #endif
 
 // -------------------------------- TonUINO Klassik --------------------------------------------------- 
//                           TonUINO Klassik , Batteriespannung über 100kOhm an BattCheckPin anlegen
  #define Bandgap 1104000L   
 

 #endif  // Ende #ifdef Batterycheck

 // ------------ Max Matrixwert des Buttonboards ------------------------------------------------------------------------------
 #ifdef Buttonboard
 uint16_t mapMax = 1024;
 #endif

 // ------------ Logischer Wert für Lautsprecher On oder Off -(Wert nicht verändern) ---------------------------------------------------
 
 uint8_t On = 1;    // HIGH-Pegel
 uint8_t Off = 0;   // LOW-Pegel
 
// ************************************************************************************************

//******************* Definitionen der Pins für TonUINO Klassik ****************************

// ------------------ Analog-Pins -------------------------------
// --------------- 3 und 5 Button-Version -----------------------
#ifndef Buttonboard                // 3 Tasten-Version
 #define ButtonPause A0            // Taste 1 - Play / Pause
 #define ButtonUp A1               // Taste 2 - Vor / Lauter
 #define ButtonDown A2             // Taste 3 - Zurück / Leiser

 #ifdef FIVEBUTTONS                // 5 Tasten-Version
 #define ButtonFourPin A3          // Taste 4 - Lauter / Vor
 #define ButtonFivePin A4          // Taste 5 - Leiser / Zurück
 #endif
 #ifndef FIVEBUTTONS
 #ifdef BatteryCheck               // Batterieüberwachung
 #define BatteryCheckPin A4        // Kontrollpin für Batterieüberwachung (Umdeklarierbar, wenn ein anderer Analogpin bei Nichtnutzung frei wird.)
 #endif
 #endif                            
#endif

// --------------- Mit 12-Buttonboard -----------------------------
#ifdef Buttonboard                 // 12 Tasten-Version mit Buttonboard
 #define Buttonmatrix A2           // Tastenmatrix 9 Tasten
 #define ButtonPause A0            // Taste 1 - Play / Pause
 #define ButtonUp A3               // Taste 2 - Vor / Lauter
 #define ButtonDown A4             // Taste 3 - Zurück / Leiser
 
 #ifdef BatteryCheck               // Batterieüberwachung
 #define BatteryCheckPin A1        // Kontrollpin für Batterieüberwachung 
 #endif                            
#endif
// --------------------------------------------------------------
#ifdef EarPhone
#define EarPhonePin A5            // Kontrollpin Kopfhörer angeschlossen
#endif

#ifdef Wecker
#define WeckerPin A6              // Eingangspin zum Abspielen Wecker-shortcut
#endif

#define RandomPin A7              // Floating Pin zur Gewinnung einer Zufallszahl

// ----------------- Digital-Pins ---------------------------------

#define BusyPin 4                 // Auswertung des Busy Signals vom DF-Player
#define LedPin 5                  // Daten für Neopixel-LED-Ring

#ifdef SpkOnOff
#define SpkOnPin 6                // Schaltsignal Lautsprecher Ein/Aus
#endif

#ifdef HW_PowerOff
#define ShutDownPin 7             // Abschaltsignal für MosFet oder Polulo-Switch
#endif

#ifdef UsbStick
#define UsbPowerPin 8             // Schaltsignal für Power USB-Stick
#endif

#define RstPin 9                  // MFRC 522 -RST
#define CS_Pin 10                 // MFRC 522 -SDA (CS)


#endif
